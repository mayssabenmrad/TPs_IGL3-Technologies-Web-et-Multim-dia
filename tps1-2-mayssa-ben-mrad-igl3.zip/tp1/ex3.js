const user = { name: "Noor", age: 10, city: "Tunis" };
userName=user.name;
userAge=user.age;
console.log(userName);
console.log(userAge);