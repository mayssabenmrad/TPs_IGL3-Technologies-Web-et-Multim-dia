function sommeClassique(a,b)
{
    return a+b;
}

const somme=(a,b)=>a+b;

//NB: syntaxe: const nomFonction = (param1, param2, ...) => expression;

console.log(sommeClassique(3,4));
console.log(somme(3,4));